

public class Test{

    public static void om(args){}

    }

    public static void main(String[] args) {
        Test Instance = new Test();

    }
}
